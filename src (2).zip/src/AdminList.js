import React, { useEffect, useState } from 'react';
import { db } from './firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import {
  Container, Box, Paper, Grid, List, ListItem, ListItemText,
  TextField, Button, Typography, useMediaQuery, createTheme,
  ThemeProvider, CircularProgress, Tabs, Tab, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, ListItemIcon,
  TablePagination
} from '@mui/material';
import { blue } from '@mui/material/colors';
import { format } from 'date-fns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: blue[700],
    },
    background: {
      default: '#f5f5f5',
      paper: '#ffffff',
    },
    text: {
      primary: '#000000',
      secondary: '#5f6368',
    },
  },
  typography: {
    fontFamily: 'Poppins, sans-serif',
  },
});

const AdminList = ({ setLoggedIn, loggedIn }) => {
  const [submissions, setSubmissions] = useState([]);
  const [userCheckIns, setUserCheckIns] = useState([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(true);
  const [tabIndex, setTabIndex] = useState(0);
  const [shiftSubTabIndex, setShiftSubTabIndex] = useState(0); // For managing sub-tabs in Shift Visitors Log
  const [detailsSubTabIndex, setDetailsSubTabIndex] = useState(0); // For managing sub-tabs in Details Visitors Log
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const isMobile = useMediaQuery('(max-width:600px)');

  const [additionalTableData, setAdditionalTableData] = useState([
    { label: 'Condenser water dip slide test result as of: 30th October 2022', value: '10²', color: 'blue' },
    { label: 'Chilled water dip slide test result as of: 02nd November 2022', value: '10²', color: 'blue' },
    { label: 'Condenser system Make-up (m³ / USG)', value: '5243', color: 'red' },
    { label: 'Condenser system Blowdown (m³ / USG)', value: '950', color: 'red' },
    { label: 'Chilled water system Make-up (m³ / USG)', value: '0.62', color: 'red' },
    { label: 'C.O.C based on conductivity (Condenser/Make-up)', value: '8.0', color: 'blue' },
    { label: 'C.O.C based on (CT make-up/CT blowdown)', value: '5.5', color: 'blue' },
    { label: 'MIOX Running Hours (Hr.)', value: '344.0 hrs.', color: 'black' },
  ]);

  const handleTabChange = (event, newIndex) => {
    setTabIndex(newIndex);
  };

  const handleShiftSubTabChange = (event, newSubIndex) => {
    setShiftSubTabIndex(newSubIndex);
  };

  const handleDetailsSubTabChange = (event, newSubIndex) => {
    setDetailsSubTabIndex(newSubIndex);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  const handleRowsPerPageChange = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleAdditionalTableChange = (e, index) => {
    const newTableData = [...additionalTableData];
    newTableData[index].value = e.target.value;
    setAdditionalTableData(newTableData);
  };

  const handleSaveAdditionalTable = async () => {
    const additionalDataDoc = doc(db, 'additionalTable', 'additionalTableData');
    await setDoc(additionalDataDoc, { data: additionalTableData });
    alert('Additional data saved successfully!');
  };

  const handleDownloadReport = () => {
    const doc = new jsPDF();
    doc.text('Visitor Log Report', 20, 10);
    const tableData = filteredCheckIns.flatMap((checkIn, index) =>
      checkIn.checkIns.map((ci) => [
        index + 1,
        checkIn.name,
        checkIn.companyName,
        checkIn.purpose,
        checkIn.phoneNumber,
        ci.checkInDate,
        ci.checkInTime,
        ci.checkOutDate || 'Not checked out yet',
        ci.checkOutTime || 'Not checked out yet',
        ci.signature ? { content: '', image: ci.signature, fit: [30, 10] } : 'N/A'
      ])
    );
    doc.autoTable({
      head: [['No.', 'Name', 'Company', 'Purpose', 'Phone Number', 'Check-in Date', 'Check-in Time', 'Check-out Date', 'Check-out Time', 'Signature']],
      body: tableData,
      didDrawCell: (data) => {
        if (data.column.dataKey === 9 && data.cell.raw.image) {
          doc.addImage(data.cell.raw.image, 'PNG', data.cell.x + 2, data.cell.y + 2, 30, 10);
        }
      },
    });
    doc.save('visitor_log_report.pdf');
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const shiftHandOversSnapshot = await getDocs(collection(db, 'shiftHandOvers'));
      const shiftHandOversData = shiftHandOversSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setSubmissions(shiftHandOversData);

      const userCheckInsSnapshot = await getDocs(collection(db, 'userCheckIns'));
      const userCheckInsData = userCheckInsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setUserCheckIns(userCheckInsData);

      setLoading(false);
    };
    fetchData();
  }, []);

  const renderSubmissions = (plantName) => {
    return submissions
      .filter(submission => submission.plantName === plantName)
      .map((submission, index) => (
        <ListItem key={submission.id} button component={Link} to={`/admin/${submission.id}`}>
          <ListItemIcon>
            <Typography variant="body1" sx={{ color: '#000' }}>
              {index + 1}.
            </Typography>
          </ListItemIcon>
          <ListItemText
            primary={format(new Date(submission.date), 'dd/MM/yyyy')}
            secondary={`Time: ${submission.time}`}
            sx={{ color: '#000' }}
          />
        </ListItem>
      ));
  };

  const filteredCheckIns = userCheckIns
    .filter(checkIn => {
      const queryMatch = checkIn.name.toLowerCase().includes(searchQuery.toLowerCase()) || checkIn.phoneNumber.includes(searchQuery);
      const startDateMatch = startDate ? new Date(checkIn.checkIns[0].checkInDate) >= startDate : true;
      const endDateMatch = endDate ? new Date(checkIn.checkIns[0].checkInDate) <= endDate : true;
      return queryMatch && startDateMatch && endDateMatch;
    })
    .sort((a, b) => {
      const latestCheckOutA = Math.max(...a.checkIns.map(ci => ci.checkOutDate ? new Date(ci.checkOutDate + ' ' + ci.checkOutTime).getTime() : new Date(ci.checkInDate + ' ' + ci.checkInTime).getTime()));
      const latestCheckOutB = Math.max(...b.checkIns.map(ci => ci.checkOutDate ? new Date(ci.checkOutDate + ' ' + ci.checkOutTime).getTime() : new Date(ci.checkInDate + ' ' + ci.checkInTime).getTime()));
      return latestCheckOutB - latestCheckOutA;
    });

  return (
    <ThemeProvider theme={theme}>
      <Container component={Paper} sx={{ p: 3, mt: 3, minHeight: '100vh', backgroundColor: theme.palette.background.paper }}>
        {!loggedIn ? (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <img src={require('./logo.png')} alt="Logo" style={{ height: '50px' }} />
            </Box>
            <Box sx={{ maxWidth: 400, width: '100%' }}>
              <TextField
                label="Email"
                fullWidth
                variant="outlined"
                sx={{ mb: 2 }}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                InputLabelProps={{ style: { color: '#000' } }}
                InputProps={{
                  style: { color: '#000' },
                }}
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                variant="outlined"
                sx={{ mb: 2 }}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                InputLabelProps={{ style: { color: '#000' } }}
                InputProps={{
                  style: { color: '#000' },
                }}
              />
              <Button
                variant="contained"
                color="primary"
                fullWidth
                onClick={handleLogin}
                sx={{ mb: 2 }}
              >
                Connect
              </Button>
              <Typography variant="body2" align="center" sx={{ color: '#000' }}>
                <Link to="/forgot-password" style={{ color: '#000', textDecoration: 'none', marginRight: 10 }}>
                  Forgot your password?
                </Link>
                -
                <Link to="/question" style={{ color: '#000', textDecoration: 'none', marginLeft: 10 }}>
                  Question?
                </Link>
              </Typography>
            </Box>
          </Box>
        ) : (
          <>
            <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
              <img src={require('./logo.png')} alt="Logo" style={{ height: '50px', margin: 20 }} />
            </Box>
            <Typography variant="h5" component="h2" gutterBottom textAlign="center" sx={{ color: '#000' }}>
              Admin Panel
            </Typography>
            <Tabs value={tabIndex} onChange={handleTabChange} centered>
              <Tab label="Shift Visitors Log" />
              <Tab label="Details Visitors Log" />
              <Tab label="Water Treatment Log" />
            </Tabs>
            {loading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress color="primary" />
              </Box>
            ) : (
              <>
                {tabIndex === 0 && (
                  <Box sx={{ mt: 3 }}>
                    <Tabs value={shiftSubTabIndex} onChange={handleShiftSubTabChange} centered>
                      <Tab label="DM-006" />
                      <Tab label="DM-007" />
                    </Tabs>
                    <Box sx={{ mt: 2 }}>
                      {shiftSubTabIndex === 0 && (
                        <List dense>
                          {renderSubmissions('DM-006')}
                        </List>
                      )}
                      {shiftSubTabIndex === 1 && (
                        <List dense>
                          {renderSubmissions('DM-007')}
                        </List>
                      )}
                    </Box>
                  </Box>
                )}
                {tabIndex === 1 && (
                  <Box sx={{ mt: 3 }}>
                    <Tabs value={detailsSubTabIndex} onChange={handleDetailsSubTabChange} centered>
                      <Tab label="DM-006" />
                      <Tab label="DM-007" />
                    </Tabs>
                    <Box sx={{ mt: 2 }}>
                      {detailsSubTabIndex === 0 && (
                        <Box>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <TextField
                              label="Search with Name or Phone No."
                              variant="outlined"
                              fullWidth
                              value={searchQuery}
                              onChange={handleSearchChange}
                              sx={{ mr: 2 }}
                            />
                            <LocalizationProvider dateAdapter={AdapterDateFns}>
                              <DatePicker
                                label="Start Date"
                                value={startDate}
                                onChange={(newValue) => setStartDate(newValue)}
                                renderInput={(params) => <TextField {...params} sx={{ mr: 2 }} />}
                              />
                              <DatePicker
                                label="End Date"
                                value={endDate}
                                onChange={(newValue) => setEndDate(newValue)}
                                renderInput={(params) => <TextField {...params} />}
                              />
                            </LocalizationProvider>
                          </Box>
                          <Button variant="contained" color="primary" onClick={handleDownloadReport} sx={{ mb: 2 }}>
                            Download Report
                          </Button>
                          <TableContainer component={Paper}>
                            <Table sx={{ minWidth: 650 }} aria-label="visitor log table">
                              <TableHead>
                                <TableRow>
                                  <TableCell>No.</TableCell>
                                  <TableCell>Name</TableCell>
                                  <TableCell>Company</TableCell>
                                  <TableCell>Purpose</TableCell>
                                  <TableCell>Phone Number</TableCell>
                                  <TableCell>Check-in Date</TableCell>
                                  <TableCell>Check-in Time</TableCell>
                                  <TableCell>Check-out Date</TableCell>
                                  <TableCell>Check-out Time</TableCell>
                                  <TableCell>Signature</TableCell>
                                </TableRow>
                              </TableHead>
                              <TableBody>
                                {filteredCheckIns.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((checkIn, index) =>
                                  checkIn.checkIns.map((ci, ciIndex) => (
                                    <TableRow key={`${checkIn.id}-${ciIndex}`}>
                                      <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                                      <TableCell>{checkIn.name}</TableCell>
                                      <TableCell>{checkIn.companyName}</TableCell>
                                      <TableCell>{checkIn.purpose}</TableCell>
                                      <TableCell>{checkIn.phoneNumber}</TableCell>
                                      <TableCell>{ci.checkInDate}</TableCell>
                                      <TableCell>{ci.checkInTime}</TableCell>
                                      <TableCell sx={{ color: ci.checkOutDate ? 'inherit' : 'red' }}>
                                        {ci.checkOutDate || 'Not checked out yet'}
                                      </TableCell>
                                      <TableCell sx={{ color: ci.checkOutTime ? 'inherit' : 'red' }}>
                                        {ci.checkOutTime || 'Not checked out yet'}
                                      </TableCell>
                                      <TableCell>
                                        {ci.signature ? <img src={ci.signature} alt="Signature" style={{ width: '100px', height: '50px' }} /> : 'N/A'}
                                      </TableCell>
                                    </TableRow>
                                  ))
                                )}
                              </TableBody>
                            </Table>
                          </TableContainer>
                          <TablePagination
                            component="div"
                            count={filteredCheckIns.length}
                            page={page}
                            onPageChange={handlePageChange}
                            rowsPerPage={rowsPerPage}
                            onRowsPerPageChange={handleRowsPerPageChange}
                          />
                        </Box>
                      )}
                      {detailsSubTabIndex === 1 && (
                        <Box>
                          {/* Render archived data or other content for the second sub-tab */}
                          {/* Example: <Typography>Archived Data</Typography> */}
                        </Box>
                      )}
                    </Box>
                  </Box>
                )}
                {tabIndex === 2 && (
                  <Box sx={{ mt: 3 }}>
                    <TableContainer component={Paper}>
                      <Table>
                        <TableBody>
                          {additionalTableData.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell sx={{ color: item.color }}>{item.label}</TableCell>
                              <TableCell>
                                {index < 2 ? (
                                  <>
                                    <Typography component="span" style={{ color: item.color, marginRight: '4px' }}>10</Typography>
                                    <TextField
                                      value={item.value.replace('10', '')}
                                      onChange={(e) => handleAdditionalTableChange(e, index)}
                                      sx={{ color: item.color, width: '30px', marginTop: -3, padding: 0 }}
                                      InputProps={{ sx: { padding: 0 } }}
                                      variant="standard"
                                      disabled
                                    />
                                  </>
                                ) : (
                                  <TextField
                                    value={item.value}
                                    onChange={(e) => handleAdditionalTableChange(e, index)}
                                    InputProps={{ sx: { padding: 0 } }}
                                    disabled
                                  />
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <Button variant="contained" color="primary" onClick={handleSaveAdditionalTable} sx={{ mt: 2 }} disabled>
                      Save Additional Data
                    </Button>
                  </Box>
                )}
              </>
            )}
          </>
        )}
      </Container>
    </ThemeProvider>
  );
};

export default AdminList;
