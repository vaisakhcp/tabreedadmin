// Assuming your service worker is in the 'public' directory
import * as serviceWorker from './serviceWorker';

serviceWorker.register();
