import React, { useEffect, useState } from 'react';
import { db } from './firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import {
  Container,
  Box,
  Paper,
  Grid,
  List,
  ListItem,
  ListItemText,
  TextField,
  Button,
  Typography,
  useMediaQuery,
  createTheme,
  ThemeProvider,
  Divider,
  CircularProgress,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  ListItemIcon,
} from '@mui/material';
import { blue } from '@mui/material/colors';
import { format } from 'date-fns';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: blue[700],
    },
    background: {
      default: '#f5f5f5',
      paper: '#ffffff',
    },
    text: {
      primary: '#000000',
      secondary: '#5f6368',
    },
  },
  typography: {
    fontFamily: 'Poppins, sans-serif',
  },
});

const AdminList = ({ setLoggedIn, loggedIn }) => {
  const [submissions, setSubmissions] = useState([]);
  const [userCheckIns, setUserCheckIns] = useState([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(true);
  const [tabIndex, setTabIndex] = useState(0);
  const [selectedSubmission, setSelectedSubmission] = useState(null);
  const [selectedCheckIn, setSelectedCheckIn] = useState(null);
  const isMobile = useMediaQuery('(max-width:600px)');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const shiftHandOversSnapshot = await getDocs(collection(db, 'shiftHandOvers'));
      const shiftHandOversData = shiftHandOversSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setSubmissions(shiftHandOversData);

      const userCheckInsSnapshot = await getDocs(collection(db, 'userCheckIns'));
      const userCheckInsData = userCheckInsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setUserCheckIns(userCheckInsData);

      setLoading(false);
    };
    fetchData();
  }, []);

  const handleLogin = () => {
    if (username === 'mnoushad@tabreed.ae' && password === '#Admin%Tabreed*') {
      setLoggedIn(true);
    } else {
      alert('Invalid credentials');
    }
  };

  const renderSubmissions = (plantName) => {
    return submissions
      .filter(submission => submission.plantName === plantName)
      .map((submission, index) => (
        <ListItem key={submission.id} button component={Link} to={`/admin/${submission.id}`}>
          <ListItemIcon>
            <Typography variant="body1" sx={{ color: '#000' }}>
              {index + 1}.
            </Typography>
          </ListItemIcon>
          <ListItemText
            primary={format(new Date(submission.date), 'dd/MM/yyyy')}
            secondary={`Time: ${submission.time}`}
            sx={{ color: '#000' }}
          />
        </ListItem>
      ));
  };

  const handleTabChange = (event, newIndex) => {
    setTabIndex(newIndex);
    if (newIndex === 1) {
      setSelectedSubmission(null); // Reset the selected submission when switching to the Details tab
      setSelectedCheckIn(null); // Reset the selected check-in when switching to the Details tab
    }
  };

  const handleSubmissionClick = (submission) => {
    setSelectedSubmission(submission);
  };

  const handleCheckInClick = (checkIn) => {
    setSelectedCheckIn(checkIn);
  };

  return (
    <ThemeProvider theme={theme}>
      <Container component={Paper} sx={{ p: 3, mt: 3, minHeight: '100vh', backgroundColor: theme.palette.background.paper }}>
        {!loggedIn ? (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <img src={require('./logo.png')} alt="Logo" style={{ height: '50px' }} />
            </Box>
            <Box sx={{ maxWidth: 400, width: '100%' }}>
              <TextField
                label="Email"
                fullWidth
                variant="outlined"
                sx={{ mb: 2 }}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                InputLabelProps={{ style: { color: '#000' } }}
                InputProps={{
                  style: { color: '#000' },
                }}
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                variant="outlined"
                sx={{ mb: 2 }}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                InputLabelProps={{ style: { color: '#000' } }}
                InputProps={{
                  style: { color: '#000' },
                }}
              />
              <Button
                variant="contained"
                color="primary"
                fullWidth
                onClick={handleLogin}
                sx={{ mb: 2 }}
              >
                Connect
              </Button>
              <Typography variant="body2" align="center" sx={{ color: '#000' }}>
                <Link to="/forgot-password" style={{ color: '#000', textDecoration: 'none', marginRight: 10 }}>
                  Forgot your password?
                </Link>
                -
                <Link to="/question" style={{ color: '#000', textDecoration: 'none', marginLeft: 10 }}>
                  Question?
                </Link>
              </Typography>
            </Box>
          </Box>
        ) : (
          <>
            <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
              <img src={require('./logo.png')} alt="Logo" style={{ height: '50px', margin: 20 }} />
            </Box>
            <Typography variant="h5" component="h2" gutterBottom textAlign="center" sx={{ color: '#000' }}>
              Admin Panel
            </Typography>
            <Tabs value={tabIndex} onChange={handleTabChange} centered>
              <Tab label="Current Data" />
              <Tab label="Details" />
            </Tabs>
            {loading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress color="primary" />
              </Box>
            ) : (
              <>
                {tabIndex === 0 && (
                  <Grid container spacing={3} justifyContent="center">
                    <Grid item xs={12}>
                      <Paper sx={{ p: 2, mb: 2, backgroundColor: theme.palette.background.paper }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Typography variant="h5" component="h2" sx={{ color: 'grey', ml: 'auto', textAlign: 'right' }}>
                            DM-006
                          </Typography>
                        </Box>
                        <Divider sx={{ backgroundColor: '#000', mb: 2 }} />
                        <List dense>
                          {renderSubmissions('DM-006')}
                        </List>
                      </Paper>
                    </Grid>
                    <Grid item xs={12}>
                      <Paper sx={{ p: 2, mb: 2, backgroundColor: theme.palette.background.paper }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Typography variant="h5" component="h2" sx={{ color: 'grey', ml: 'auto', textAlign: 'right' }}>
                            DM-007
                          </Typography>
                        </Box>
                        <Divider sx={{ backgroundColor: '#000', mb: 2 }} />
                        <List dense>
                          {renderSubmissions('DM-007')}
                        </List>
                      </Paper>
                    </Grid>
                  </Grid>
                )}
                {tabIndex === 1 && (
                  <Box sx={{ mt: 3 }}>
                    {!selectedCheckIn ? (
                      <>
                        <Typography variant="h6" sx={{ color: '#000', mb: 2 }}>
                          User Check-ins
                        </Typography>
                        <List>
                          {userCheckIns.map((checkIn, index) => (
                            <ListItem
                              key={checkIn.id}
                              button
                              onClick={() => handleCheckInClick(checkIn)}
                            >
                              <ListItemIcon>
                                <Typography variant="body1" sx={{ color: '#000' }}>
                                  {index + 1}.
                                </Typography>
                              </ListItemIcon>
                              <ListItemText
                                primary={checkIn.phoneNumber}
                                sx={{ color: '#000' }}
                              />
                            </ListItem>
                          ))}
                        </List>
                      </>
                    ) : (
                      <Box sx={{ mt: 3 }}>
                        <Button onClick={() => setSelectedCheckIn(null)} variant="outlined" sx={{ mb: 3 }}>
                          Back to List
                        </Button>
                        <Typography variant="h6" sx={{ color: '#000', mb: 2 }}>
                          User Details
                        </Typography>
                        <Typography variant="body1" sx={{ color: '#000', mb: 1 }}>
                          Name: {selectedCheckIn.name}
                        </Typography>
                        <Typography variant="body1" sx={{ color: '#000', mb: 1 }}>
                          Company: {selectedCheckIn.companyName}
                        </Typography>
                        <Typography variant="body1" sx={{ color: '#000', mb: 1 }}>
                          Purpose: {selectedCheckIn.purpose}
                        </Typography>
                        <Typography variant="body1" sx={{ color: '#000', mb: 2 }}>
                          Phone Number: {selectedCheckIn.phoneNumber}
                        </Typography>
                        <Typography variant="h6" sx={{ color: '#000', mb: 2 }}>
                          Check-in and Check-out Details
                        </Typography>
                        <TableContainer component={Paper}>
                          <Table sx={{ minWidth: 650 }} aria-label="check-in table">
                            <TableHead>
                              <TableRow>
                                <TableCell>Check-in Date</TableCell>
                                <TableCell>Check-in Time</TableCell>
                                <TableCell>Check-out Date</TableCell>
                                <TableCell>Check-out Time</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {selectedCheckIn.checkIns.map((checkIn, index) => (
                                <TableRow key={index}>
                                  <TableCell>{checkIn.checkInDate}</TableCell>
                                  <TableCell>{checkIn.checkInTime}</TableCell>
                                  <TableCell>{checkIn.checkOutDate || 'N/A'}</TableCell>
                                  <TableCell>{checkIn.checkOutTime || 'N/A'}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Box>
                    )}
                  </Box>
                )}
              </>
            )}
          </>
        )}
      </Container>
    </ThemeProvider>
  );
};

export default AdminList;
