import React, { useEffect, useState } from 'react';
import { db } from './firebaseConfig';
import { doc, getDoc } from 'firebase/firestore';
import { useParams, Link } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  useMediaQuery,
  Grid,
  Breadcrumbs,
  CircularProgress,
} from '@mui/material';

const AdminDetail = () => {
  const { id } = useParams();
  const [submission, setSubmission] = useState(null);
  const [loading, setLoading] = useState(true);
  const isMobile = useMediaQuery('(max-width:600px)');

  useEffect(() => {
    const fetchData = async () => {
      const docRef = doc(db, 'shiftHandOvers', id);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setSubmission(docSnap.data());
      } else {
        console.log("No such document!");
      }
      setLoading(false);
    };

    fetchData();
  }, [id]);

  return (
    <Container component={Paper} sx={{ p: 3, mt: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
        <img src={require('./logo.png')} alt="Logo" style={{ height: '50px', margin: 20 }} />
      </Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Submission Details
      </Typography>
      <Breadcrumbs aria-label="breadcrumb" sx={{ mb: 2 }}>
        <Link to="/admin" style={{ color: '#1976d2' }}>Admin Panel</Link>
        <Typography color="textPrimary">Submission Details</Typography>
      </Breadcrumbs>
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
          <CircularProgress />
        </Box>
      ) : submission ? (
        <div>
          <Typography variant="h5" component="h2" gutterBottom>
            {submission.plantName}
          </Typography>
          <Typography variant="body1" gutterBottom>
            Date: {submission.date}
          </Typography>
          <Typography variant="body1" gutterBottom>
            Time: {submission.time}
          </Typography>
          <Typography variant="body1" gutterBottom>
            Shift: {submission.shift}
          </Typography>
          <Typography variant="h6" component="h3" gutterBottom>
            Equipment Status
          </Typography>
          {!isMobile ? (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell><strong>Equipment List</strong></TableCell>
                  <TableCell><strong>Plant Actual Parameters</strong></TableCell>
                  <TableCell><strong>Status / Remarks</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {submission.equipmentStatus.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.equipment}</TableCell>
                    <TableCell>{item.parameters}</TableCell>
                    <TableCell>{item.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            submission.equipmentStatus.map((item, index) => (
              <Box key={index} sx={{ mb: 2, p: 2, border: '1px solid #ddd', borderRadius: '4px' }}>
                <Typography variant="body2" gutterBottom>
                  <strong>Equipment:</strong> {item.equipment}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>Plant Actual Parameters:</strong> {item.parameters}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>Status / Remarks:</strong> {item.status}
                </Typography>
              </Box>
            ))
          )}
          <Typography variant="body1" gutterBottom>
            Activities: {submission.activities.join(', ')}
          </Typography>
          <Typography variant="body1" gutterBottom>
            Equipment Not Available: {submission.equipmentNotAvailable.join(', ')}
          </Typography>
          <Grid container spacing={3} sx={{ mt: 4 }}>
            <Grid item xs={12} md={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="body2" sx={{ mb: 2, fontSize: '1rem' }}>
                  I confirm that I have explained the plant status and activities carried out during my shift to the replacing operator.
                </Typography>
                {submission.operatorSignature && (
                  <img
                    src={submission.operatorSignature}
                    alt="Operator Signature"
                    style={{
                      display: 'block',
                      margin: '10px auto',
                      border: '1px solid #000',
                      maxWidth: '100%',
                      height: 'auto',
                      objectFit: 'contain'
                    }}
                  />
                )}
                <Typography variant="body1" sx={{ mt: 2, fontSize: '1.2rem', fontWeight: 'bold' }}>
                  Operator Signature
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="body2" sx={{ mb: 2, fontSize: '1rem' }}>
                  I confirm that I understand plant status and activities carried out as explained by the shift operator.
                </Typography>
                {submission.supervisorSignature && (
                  <img
                    src={submission.supervisorSignature}
                    alt="Opeator Signature"
                    style={{
                      display: 'block',
                      margin: '10px auto',
                      border: '1px solid #000',
                      maxWidth: '100%',
                      height: 'auto',
                      objectFit: 'contain'
                    }}
                  />
                )}
                <Typography variant="body1" sx={{ mt: 2, fontSize: '1.2rem', fontWeight: 'bold' }}>
                  Operator Signature
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </div>
      ) : (
        <Typography variant="body1" gutterBottom>Loading...</Typography>
      )}
      <Link to="/admin" style={{ color: '#1976d2', marginTop: '20px', display: 'block' }}>Back to List</Link>
    </Container>
  );
};

export default AdminDetail;
